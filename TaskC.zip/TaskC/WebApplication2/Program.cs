using System.Net;
using System.Net.Sockets;
using System.Text;

namespace TaskC;

/// <summary>
/// Modern TCP Server/Client Implementation using Async/Await Pattern
///
/// This program demonstrates a scalable TCP server that can handle multiple concurrent clients
/// without dedicating OS threads to each connection. It uses the Task-based Asynchronous Pattern (TAP)
/// which is the recommended approach in modern .NET applications.
///
/// Usage:
///   dotnet run -- server   (starts the TCP server on port 5000)
///   dotnet run -- client   (connects to the server)
/// </summary>
class Program
{
    private const string Host = "127.0.0.1";
    private const int Port = 5000;

    /// <summary>
    /// Tracks the current number of connected clients.
    /// Uses Interlocked operations for thread-safe increment/decrement.
    /// </summary>
    private static int _connectedClients = 0;

    /// <summary>
    /// Application entry point with async support.
    /// Determines whether to run as server or client based on command-line argument.
    /// Handles graceful shutdown via CancellationToken when user presses Ctrl+C.
    /// </summary>
    static async Task Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  dotnet run -- server");
            Console.WriteLine("  dotnet run -- client");
            return;
        }

        // Create CancellationTokenSource to enable graceful shutdown
        // When Ctrl+C is pressed, all async operations will be notified to stop
        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (sender, e) =>
        {
            e.Cancel = true;  // Don't terminate immediately - let cleanup happen
            cts.Cancel();     // Signal all async operations to cancel
            Console.WriteLine("\n[Shutting down gracefully...]");
        };

        try
        {
            switch (args[0].ToLowerInvariant())
            {
                case "server":
                    await RunServerAsync(cts.Token);
                    break;
                case "client":
                    await RunClientAsync(cts.Token);
                    break;
                default:
                    Console.WriteLine($"Unknown mode '{args[0]}'. Use 'server' or 'client'.");
                    break;
            }
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("[Shutdown complete]");
        }
    }

    /// <summary>
    /// Runs the TCP server that accepts and handles multiple client connections concurrently.
    ///
    /// Modern async approach vs old threaded approach:
    /// - OLD: Thread.Start() creates a dedicated OS thread per client (expensive, limited scalability)
    /// - NEW: async/await uses Task-based concurrency (efficient, can handle thousands of clients)
    ///
    /// Key benefits:
    /// 1. AcceptTcpClientAsync() - Awaits connections without blocking a thread
    /// 2. Each client handled via HandleClientAsync() - Concurrent processing without dedicated threads
    /// 3. CancellationToken - Enables clean shutdown when server stops
    /// 4. Task tracking - Ensures all client connections are properly closed on shutdown
    /// </summary>
    static async Task RunServerAsync(CancellationToken cancellationToken)
    {
        var listener = new TcpListener(IPAddress.Parse(Host), Port);
        listener.Start();
        Console.WriteLine($"[Server] Listening on {Host}:{Port}  (Ctrl+C to stop)\n");

        try
        {
            // Maintain list of all active client Tasks
            // Allows us to wait for graceful completion on shutdown
            var clientTasks = new List<Task>();

            while (!cancellationToken.IsCancellationRequested)
            {
                // Asynchronously wait for incoming connection
                // Unlike AcceptTcpClient(), this doesn't block a thread while waiting
                TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken);
                string clientAddress = client.Client.RemoteEndPoint?.ToString() ?? "unknown";

                // Atomically increment the connected clients counter
                // Interlocked ensures thread-safety when multiple clients connect simultaneously
                int currentCount = Interlocked.Increment(ref _connectedClients);
                Console.WriteLine($"[Server] Client connected: {clientAddress}");
                Console.WriteLine($"[Server] Total connected clients: {currentCount}\n");

                // Start handling this client asynchronously
                // This doesn't wait for the client to finish - it continues accepting new connections
                // Fire-and-forget pattern: client handling runs concurrently
                Task clientTask = HandleClientAsync(client, clientAddress, cancellationToken);
                clientTasks.Add(clientTask);

                // Periodically remove completed tasks to prevent unbounded list growth
                // Only keeps active client Tasks in memory
                clientTasks.RemoveAll(t => t.IsCompleted);
            }

            // Server is shutting down - wait for all active clients to finish gracefully
            await Task.WhenAll(clientTasks);
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("[Server] Stopped accepting connections.");
        }
        finally
        {
            // Always stop the listener to release the port
            listener.Stop();
        }
    }

    /// <summary>
    /// Handles communication with a single connected client asynchronously.
    ///
    /// Modern improvements:
    /// - Uses StreamReader/StreamWriter instead of raw byte arrays for text communication
    /// - ReadLineAsync()/WriteLineAsync() are non-blocking - thread can serve other clients while waiting
    /// - Automatic UTF-8 encoding/decoding
    /// - Proper resource cleanup via using statements and finally block
    ///
    /// Communication protocol:
    /// 1. Read line from client
    /// 2. Process the request
    /// 3. Send response back
    /// 4. Repeat until client sends "QUIT" or disconnects
    /// </summary>
    /// <param name="client">The connected TCP client</param>
    /// <param name="clientAddress">Client's network address for logging</param>
    /// <param name="cancellationToken">Token to signal when server is shutting down</param>
    static async Task HandleClientAsync(TcpClient client, string clientAddress, CancellationToken cancellationToken)
    {
        // Task.CurrentId helps identify which async task is handling this client (for logging)
        int taskId = Task.CurrentId ?? 0;
        Console.WriteLine($"[Task {taskId}] Serving {clientAddress}");

        try
        {
            // Using statements ensure proper disposal of resources
            // TcpClient, NetworkStream, and StreamWriter/Reader are all disposed automatically
            using (client)
            {
                await using NetworkStream stream = client.GetStream();
                using var reader = new StreamReader(stream, Encoding.UTF8);
                await using var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

                while (!cancellationToken.IsCancellationRequested)
                {
                    // Asynchronously read a line from the client
                    // While waiting for data, the thread can handle other work
                    // This is the key advantage over synchronous stream.Read()
                    string? request = await reader.ReadLineAsync(cancellationToken);

                    // Null indicates client closed the connection
                    if (request == null)
                    {
                        Console.WriteLine($"[Task {taskId}] {clientAddress} disconnected.");
                        break;
                    }

                    request = request.Trim();
                    Console.WriteLine($"[Task {taskId}] ← \"{request}\"  from {clientAddress}");

                    // Process the request and generate a response
                    string response = ProcessRequest(request, taskId);

                    // Asynchronously send response back to client
                    // AutoFlush = true ensures data is sent immediately
                    await writer.WriteLineAsync(response);
                    Console.WriteLine($"[Task {taskId}] → \"{response}\"  to {clientAddress}");

                    // Exit loop if client sent QUIT command
                    if (request.Equals("QUIT", StringComparison.OrdinalIgnoreCase))
                        break;
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Server is shutting down - this is expected
            Console.WriteLine($"[Task {taskId}] Cancelled: {clientAddress}");
        }
        catch (IOException ex)
        {
            // Network error (e.g., client disconnected abruptly)
            Console.WriteLine($"[Task {taskId}] IO error: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Unexpected error
            Console.WriteLine($"[Task {taskId}] Error: {ex.Message}");
        }
        finally
        {
            // Always decrement the client counter when connection closes
            // Interlocked.Decrement is atomic and thread-safe
            int currentCount = Interlocked.Decrement(ref _connectedClients);
            Console.WriteLine($"[Task {taskId}] Connection closed: {clientAddress}");
            Console.WriteLine($"[Server] Total connected clients: {currentCount}\n");
        }
    }

    /// <summary>
    /// Processes a client request and generates an appropriate response.
    ///
    /// This method implements a simple command protocol:
    /// - PING  → Returns "PONG" (connectivity test)
    /// - HELLO → Returns greeting with Task ID
    /// - TIME  → Returns current server time
    /// - QUIT  → Returns goodbye message (client will disconnect)
    /// - Other → Echoes the message back to client
    /// </summary>
    /// <param name="request">The command/message from the client</param>
    /// <param name="taskId">The Task ID handling this client (for personalized responses)</param>
    /// <returns>Response message to send back to client</returns>
    static string ProcessRequest(string request, int taskId) =>
        request.ToUpperInvariant() switch
        {
            "PING" => "PONG",
            "HELLO" => $"Hello! You are served by Task {taskId}.",
            "TIME" => $"Server time: {DateTime.Now:yyyy-MM-dd HH:mm:ss}",
            "QUIT" => "Goodbye!",
            _ => $"ECHO: {request}"
        };

    /// <summary>
    /// Runs the TCP client that connects to the server and allows interactive communication.
    ///
    /// Client workflow:
    /// 1. Asynchronously connect to the server
    /// 2. Create StreamReader/StreamWriter for text-based communication
    /// 3. Enter interactive loop:
    ///    - Read user input from console
    ///    - Send to server
    ///    - Receive and display response
    /// 4. Exit when user types "QUIT" or presses Ctrl+C
    ///
    /// Async benefits:
    /// - ConnectAsync() doesn't block while establishing connection
    /// - WriteLineAsync()/ReadLineAsync() allow responsive UI even during network I/O
    /// </summary>
    /// <param name="cancellationToken">Token to signal when user presses Ctrl+C</param>
    static async Task RunClientAsync(CancellationToken cancellationToken)
    {
        Console.WriteLine($"[Client] Connecting to {Host}:{Port} ...");

        try
        {
            // Create and asynchronously connect to the server
            using var tcp = new TcpClient();
            await tcp.ConnectAsync(Host, Port, cancellationToken);

            // Set up text-based communication streams
            await using NetworkStream ns = tcp.GetStream();
            using var reader = new StreamReader(ns, Encoding.UTF8);
            await using var writer = new StreamWriter(ns, Encoding.UTF8) { AutoFlush = true };

            Console.WriteLine("[Client] Connected!");
            Console.WriteLine("[Client] Commands: PING | HELLO | TIME | QUIT | <any text>\n");

            // Interactive communication loop
            while (!cancellationToken.IsCancellationRequested)
            {
                Console.Write("> ");

                // Read user input from console
                // Console.ReadLine() is synchronous, but that's acceptable for UI input
                string? input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                    continue;

                // Send the command/message to server asynchronously
                await writer.WriteLineAsync(input);

                // Wait for and read the server's response
                string? response = await reader.ReadLineAsync(cancellationToken);
                Console.WriteLine($"[Server]: {response}\n");

                // Exit loop if user typed QUIT
                if (input.Equals("QUIT", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("[Client] Disconnecting.");
                    break;
                }
            }
        }
        catch (OperationCanceledException)
        {
            // User pressed Ctrl+C - this is expected
            Console.WriteLine("[Client] Cancelled.");
        }
        catch (SocketException ex)
        {
            // Connection failed - server might not be running
            Console.WriteLine($"[Client] Cannot connect: {ex.Message}");
            Console.WriteLine("[Client] Make sure the server is already running.");
        }
        catch (Exception ex)
        {
            // Unexpected error during communication
            Console.WriteLine($"[Client] Error: {ex.Message}");
        }
    }
}
